package i2.application.isidorv2.metier.service.test;
/**
 * 
 */

import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalerAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalageLotExterneServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RetourServiceAsyncBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceStub;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroisementServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroiserAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.DetailLotPublieServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.FiltreAttributServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocodageServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.LotEntreeServiceBean;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * Classe client d'appel du service ISIDOR.
 * 
 * @author R�mi BOUILLY
 * 
 * @Date 19/10/2016
 * 
 * @Project ISIDORV3.
 *
 */
public class TestServiceReferentiel {
	
	/**
	 * LOG.
	 */
	static final Log log = LogFactory.getLog(TestServiceReferentiel.class);

	/**
	 * URL du service.
	 */
	//URL PLATEFORME RECETTE INTRANET
	//private final static String SERVICE_URL = "http://isidor3-recette2.dtecitm.cerema.i2/isidorv3/services/ServiceReferentielServiceAsync";
	//URL PLATEFORME KLEE INTERNET
	private final static String SERVICE_URL = "http://isidorv3.rct01.kleegroup.com/ISIDORV3-1.3.3/services/ServiceReferentielServiceAsync";
	//URL PLATEFORME RECETTE INTERNET
	//private final static String SERVICE_URL = "http://isidor.application.developpement-durable.gouv.fr/isidorv3/services/ServiceReferentielServiceAsync";
	
	private final static String DATE_REFERENTIEL_FORMAT = "DD/MM/yyyy";
	
	/**
	 * M�thode principale.
	 * @param args liste des arguments.
	 * 
	 * @throws Exception si erreur.
	 */
	public static void main(String[] args) throws Exception {
		if(args.length==0){
			args=new String[2];
			args[0]="geocoder";
			args[1]="-h";
			TestServiceReferentiel.geocoder(args);
			args[0]="croiser";
			TestServiceReferentiel.croiser(args);
		}
		else if(args[0].equals("croiser")){
			TestServiceReferentiel.croiser(args);
		} else if (args[0].equals("geocoder")){
			TestServiceReferentiel.geocoder(args);
		} else if (args[0].equals("recaler")){
			TestServiceReferentiel.recaler(args);
		} else if(args[0].equals("interroger")) {
			TestServiceReferentiel.interrogerDonnees(args);
		}
	}
	
	/**
	 * 
	 * @param sDate
	 * @param sFormat
	 * @return
	 * @throws ParseException
	 */
	private static Date parseDate(String sDate, String sFormat) throws ParseException {
		SimpleDateFormat format = (SimpleDateFormat) DateFormat.getDateInstance(DateFormat.FULL, Locale.FRANCE);
		format.applyPattern(sFormat);
		format.setTimeZone(TimeZone.getDefault());
		String[] ss = TimeZone.getAvailableIDs();
		return format.parse(sDate);
	}
	/**
	 * M�thode qui lance le webservice de recalage.
	 * @param args les arguments.
	 * @throws Exception si erreur.
	 */
	public static void recaler(String[] args) throws Exception {
		Options opt = new Options();
		opt.addOption("portee", true, "Portee du lot ROUTE/CHAUSSEE/VOIE");
		opt.addOption("localisation", true, "Type de localisation (PLO)/PR/XY");
		opt.addOption("f", true, "Nom du fichier FEOR/XML");
		opt.addOption("c", false, "Calculer les localisations compl�mentaires");
		opt.addOption("rs", true, "Date du r�f�rentiel source");
		opt.addOption("rc", true, "Date du r�f�rentiel cible");
		opt.addOption("h", false, "Afficher l'aide");
		opt.addOption("o", true, "nom du fichier de sortie");
		opt.addOption("url", true, "Url d'acc�s au web service");

		BasicParser parser = new BasicParser();
		CommandLine cl = parser.parse(opt, args);

		if (cl.hasOption('h') || !cl.hasOption("f")
				|| !cl.hasOption("localisation") || !cl.hasOption("portee")) {
			System.out.println("XRIU-client (Service r�f�rentiel) ISIDORv3");
			System.out.println("Utilitaire de requ�tage du service web de recalage d'ISIDORv3");
			HelpFormatter f = new HelpFormatter();
			f.printHelp("java -jar xriu.jar recaler -f nom_fichier_xml -portee portee_lot -localisation type_localisation [-o fichier_sortie] [OPTIONS]", opt);
			return;
		}

		String portee = cl.getOptionValue("portee");
		String localisation = cl.getOptionValue("localisation");
		File fichier = new File(cl.getOptionValue("f"));
		boolean localisationComplementaire = cl.hasOption("c");
		Calendar referentielSource = null;
		Calendar referentielCible = null;
		if(cl.hasOption("rs")) {
			referentielSource = Calendar.getInstance(Locale.FRANCE);
			referentielSource.setTime(parseDate(cl.getOptionValue("rs"), DATE_REFERENTIEL_FORMAT));
		}
		if(cl.hasOption("rc")) {
			referentielCible = Calendar.getInstance(Locale.FRANCE);
			referentielCible.setTime(parseDate(cl.getOptionValue("rc"), DATE_REFERENTIEL_FORMAT));
		}
		String url = TestServiceReferentiel.SERVICE_URL;
		if (cl.hasOption("url")) {
			url = cl.getOptionValue("url");
		}

		RecalerAsync parametres = new RecalerAsync();
		parametres.setFeorXml(TestServiceReferentiel.readFile(fichier));
		parametres.setParametres(new RecalageLotExterneServiceBean());
		parametres.getParametres().setPortee(portee);
		parametres.getParametres().setLocalisation(localisation);
		parametres.getParametres().setCalculLocalisationComplementaires(localisationComplementaire);
		parametres.getParametres().setDateReferentielSource(referentielSource);
		parametres.getParametres().setDateReferentielCible(referentielCible);
		
		
		ServiceReferentielServiceStub stub = new ServiceReferentielServiceStub(url);
		RetourServiceAsyncBean response = null;
		try {
			response = stub.startrecaler(parametres);
		} catch (RemoteException e) {
			throw e;
		}

		if (response.getResultat() != null) {
			if (cl.hasOption("o")) {
				TestServiceReferentiel.writeStringTofile(new File(cl.getOptionValue("o")), response.getResultat());
			}
			else {
				TestServiceReferentiel.log.info(response.getResultat());
			}
		}
		System.out.println("Recalage effectu�.");
	}
	
	public static void interrogerDonnees(String[] args) throws Exception {
		Options opt = new Options();
		opt.addOption("m", false, "metadonnees");
		opt.addOption("thema", true, "nom de th�matique");
		opt.addOption("loca", true, "type de localisation");
		opt.addOption("o", true, "nom du fichier de sortie");
		opt.addOption("url", true, "Url d'acc�s au web service");

		BasicParser parser = new BasicParser();
		CommandLine cl = parser.parse(opt, args);
		
		if (cl.hasOption('h')) {
			System.out.println("XRIU-client (Service r�f�rentiel) ISIDORv3");
			System.out.println("Utilitaire de requ�tage du service web d'interrogation d'ISIDORv3");
			HelpFormatter f = new HelpFormatter();
			f.printHelp("java -jar xriu.jar interroger -m -thema ClasseProfilTravSectionnee -loca PR -o fichier_sortie_interrogation.xml [OPTIONS]", opt);
			return;
		}

		String url = TestServiceReferentiel.SERVICE_URL;
		if (cl.hasOption("url")) {
			url = cl.getOptionValue("url");
		}

		InterrogerDonneesAsync parametres = new InterrogerDonneesAsync();
		parametres.setParametres(new InterrogerDonneesServiceBean());
		
		//ajout date des donnees ISIDOR
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		Date date = sdf.parse("2012-01-01 00:00:00");
//		parametres.getParametres().setDateActualite(date);
		
		parametres.getParametres().setMetadonnees(cl.hasOption("m"));
		if(cl.hasOption("thema")) {
			parametres.getParametres().setNomThematique(cl.getOptionValue("thema"));
		} else {
			parametres.getParametres().setNomThematique("ClasseProfilTravSectionnee");
		}
		if(cl.hasOption("loca")) {
			parametres.getParametres().setTypeLocalisation(cl.getOptionValue("loca"));
		} else {
			parametres.getParametres().setTypeLocalisation("PR");
		}
		//ajout filtre sur la route
		FiltreAttributServiceBean filtreRoute = new FiltreAttributServiceBean();
		filtreRoute.setNomAttribut("nomRoute");
		filtreRoute.setOperateur("EGAL_A");
		filtreRoute.setOperandes(new String[] {"A0001"});
		
		//ajout filtre sur le gestionnaire
//		FiltreAttributServiceBean filtreGestion = new FiltreAttributServiceBean();
//		filtreGestion.setNomAttribut("sectionnement_gestionnaire");
//		filtreGestion.setOperateur("EGAL_A");
//		filtreGestion.setOperandes(new String[] {"DIRIF"});
//		FiltreAttributServiceBean[] filtresGeneriques = new FiltreAttributServiceBean[] {filtreRoute};
		
		//ajout filtre sur la localisation
		//localisation PLO d�but
		FiltreAttributServiceBean filtrePloDebut = new FiltreAttributServiceBean();
		filtrePloDebut.setNomAttribut("ploDebut");
		filtrePloDebut.setOperateur("EGAL_A");
		filtrePloDebut.setOperandes(new String[] {"93PR2D"});
		//localisation PLO fin
		FiltreAttributServiceBean filtrePloFin = new FiltreAttributServiceBean();
		filtrePloFin.setNomAttribut("ploFin");
		filtrePloFin.setOperateur("EGAL_A");
		filtrePloFin.setOperandes(new String[] {"93PR2D"});
		
		FiltreAttributServiceBean[] filtresGeneriques = new FiltreAttributServiceBean[] {filtreRoute, filtrePloDebut, filtrePloFin};
		//FiltreAttributServiceBean[] filtresMetiers = new FiltreAttributServiceBean[] {filtreGestion};
		parametres.getParametres().setFiltresAttributGenerique(filtresGeneriques);
		//parametres.getParametres().setFiltresAttributMetier(filtresMetiers);
		
		//parametres.getParametres().setCouverture(new String[] {"NON_CONCEDE"});
				
		ServiceReferentielServiceStub stub = new ServiceReferentielServiceStub(url);
		RetourServiceAsyncBean response = null;
		try {
			response = stub.startInterrogerDonnees(parametres);
		} catch (RemoteException e) {
			throw e;
		}

		if (response.getResultat() != null) {
			if (cl.hasOption("o")) {
				TestServiceReferentiel.log.info(response.getResultat());
				TestServiceReferentiel.writeStringTofile(new File(cl.getOptionValue("o")), response.getResultat());
			}
			else {
				TestServiceReferentiel.log.info(response.getResultat());
			}
		}
		System.out.println("Interrogation effectu�e.");
	}
	
	/**
	 * M�thode qui lance le webservice de g�ocodage.
	 * @param args les arguments.
	 * @throws Exception si erreur.
	 */
	public static void geocoder(String[] args) throws Exception {
		Options opt = new Options();

		opt.addOption("f", true, "Nom du fichier FEOR/XML");
		opt.addOption("portee", true, "Portee du lot ROUTE/VOIE/(CHAUSSEE)");
		opt.addOption("localisation", true, "Type de localisation (PLO)/PR/XY");
		
		opt.addOption("o", true, "nom du fichier de sortie");

		opt.addOption("geom", false, "Calcul de la g�om�trie (non)");
		opt.addOption("longueur", false, "Calcul de la longueur (non)");
		opt.addOption("continuite", false, "Continuite (non)");
		opt.addOption("dispech", false,
				"Inclure les dispositifs d'�changes (non)");
		opt.addOption("dom", false, "Inclure les DOM/COM (non)");
		opt.addOption("plopr", false, "PLO de type PR (non)");
		opt.addOption("norecouvrement", false,
				"Interdire les recouvrements");
		opt.addOption("toleranceAbscisse", true, "Tolerance d'abscisse");
		opt.addOption("toleranceProjection", true, "Tolerance de projection");
		opt.addOption("typeLocalisationSortie", true, "Type de localisation en sortie PLO/PR");
		opt.addOption("url", true, "Url d'acc�s au web service");

		opt.addOption("h", false, "Afficher l'aide");

		BasicParser parser = new BasicParser();
		CommandLine cl = parser.parse(opt, args);

		if (cl.hasOption('h') || !cl.hasOption("f")
				|| !cl.hasOption("localisation") || !cl.hasOption("portee")) {
			System.out.println("XRIU-client (Service r�f�rentiel) ISIDORv3");
			System.out.println("Utilitaire de requ�tage du service web de g�ocodage d'ISIDORv3");
			HelpFormatter f = new HelpFormatter();
			f
					.printHelp(
							"java -jar xriu.jar geocoder -f nom_fichier_xml -portee portee_lot -localisation type_localisation [-o fichier_sortie] [OPTIONS]",
							opt);
			return;
		}

		boolean geom = cl.hasOption("geom");
		boolean longueur = cl.hasOption("longueur");
		boolean continuite = cl.hasOption("continuite");
		boolean dispech = cl.hasOption("dispech");
		boolean dom = cl.hasOption("dom");
		boolean plopr = cl.hasOption("plopr");
		boolean recouvrement = !cl.hasOption("norecouvrement");

		File fichier = new File(cl.getOptionValue("f"));
		String portee = cl.getOptionValue("portee");

		Integer toleranceAbscisse = -1;

		if (cl.hasOption("toleranceAbscisse")) {
			toleranceAbscisse = Integer.valueOf(cl
					.getOptionValue("toleranceAbscisse"));
		}

		Integer toleranceProjection = -1;

		if (cl.hasOption("toleranceProjection")) {
			toleranceProjection = Integer.valueOf(cl
					.getOptionValue("toleranceProjection"));
		}

		String localisation = cl.getOptionValue("localisation");

		String url = TestServiceReferentiel.SERVICE_URL;

		if (cl.hasOption("url")) {
			url = cl.getOptionValue("url");
		}

		GeocoderAsync parametres = new GeocoderAsync();
		parametres.setFeorXml(TestServiceReferentiel.readFile(fichier));
		parametres.setParametres(new GeocodageServiceBean());

		parametres.getParametres().setCalculerGeometrie(geom);
		parametres.getParametres().setCalculerLongueur(longueur);
		parametres.getParametres().setContinuite(continuite);
		parametres.getParametres().setInclureDispEch(dispech);
		parametres.getParametres().setInclureDOM(dom);
		parametres.getParametres().setPloPR(plopr);
		parametres.getParametres().setPortee(portee);
		parametres.getParametres().setRecouvrement(recouvrement);
		parametres.getParametres().setToleranceAbscisse(toleranceAbscisse);
		parametres.getParametres().setToleranceProjection(toleranceProjection);
		parametres.getParametres().setTypeLocalisation(localisation);
		if(cl.hasOption("typeLocalisationSortie")){
			parametres.getParametres().setTypeLocalisationSortie(cl.getOptionValue("typeLocalisationSortie"));
		}
		
		ServiceReferentielServiceStub stub = new ServiceReferentielServiceStub(url);
		RetourServiceAsyncBean response = null;
		try {
			response = stub.startgeocoder(parametres);
		} catch (RemoteException e) {
			throw e;
		}

		if (response.getResultat() != null) {
			if (cl.hasOption("o")) {
				TestServiceReferentiel.writeStringTofile(new File(cl.getOptionValue("o")), response.getResultat());
			}
			else {
				TestServiceReferentiel.log.info(response.getResultat());
			}
		}
		System.out.println("G�ocodage effectu�.");
	}
	
	/**
	 * M�thode qui lance le webservice de croisement.
	 * @param args les arguments.
	 * @throws Exception si erreur.
	 */
	public static void croiser(String[] args) throws Exception {
		final SimpleDateFormat dateformat = new SimpleDateFormat("dd/MM/yyyy");
		
		// Options de l'application
		Options opt = new Options();
		opt.addOption("url", true, "Url d'acc�s au web service");
		opt.addOption("h", false, "Afficher l'aide");
		opt.addOption("geom", false, "Calcul de la g�om�trie (non)");
		opt.addOption("longueur", false, "Calcul de la longueur (non)");
		opt.addOption("date", true, "Date du r�f�rentiel cible du croisement (JJ/MM/AAAA)");
		opt.addOption("declassement", false, "Inclure les voies en cours de d�classement (non)");
		opt.addOption("dispech", false,"Inclure les dispositifs d'�changes (non)");
		opt.addOption("dom", false, "Inclure les DOM/COM (non)");
		opt.addOption("plopr", false, "PLO de type PR (non)");
		opt.addOption("toleranceAbscisse", true, "Tolerance d'abscisse");
		opt.addOption("toleranceProjection", true, "Tolerance de projection");
		opt.addOption("typeLocalisationSortie", true, "Type de localisation en sortie PLO/PR");
		opt.addOption("o", true, "nom du fichier FEOR de sortie");
		opt.addOption("messages", true, "nom du fichier CSV de messages de sortie");
		opt.addOption("repertoire", true, "R�pertoire o� se situent les fichiers de description des lots");
		opt.addOption("lotspublies", true, "Noms des lots publi�s (�quivalent au nom des fichiers sans l'extension), s�par�s par des points virgule, sans espaces");
		opt.addOption("lotsentree", true, "Noms des lots en entr�e (�quivalent au nom des fichiers sans l'extension), s�par�s par des points virgule, sans espaces");

		// R�cup�ration des options entr�es
		BasicParser parser = new BasicParser();
		CommandLine cl = parser.parse(opt, args);

		//Affichage de l'aide
		if (cl.hasOption('h')) {
			System.out.println("XRIU-client (Service r�f�rentiel) ISIDORv3");
			System.out.println("Utilitaire de requ�tage du service web de croisement d'ISIDORv3");
			HelpFormatter f = new HelpFormatter();
			f.printHelp("java -jar xriu.jar croiser -o fichier_sortie.xml -messages fichier_messages.csv [-lotspublies lot1;lot2;lot3] [-lotsentree lot4;lot5;lot6] [OPTIONS]",opt);
			return;
		}
		
		//Construction du bean croisement
		CroiserAsync parametres = new CroiserAsync();
		CroisementServiceBean croisementServiceBean = new CroisementServiceBean();
		
		croisementServiceBean.setCalculerGeometrie(cl.hasOption("geom"));
		croisementServiceBean.setCalculerLongueur(cl.hasOption("longueur"));
		//--date r�f�rentiel
//		Calendar dateRef = null;
//		if (cl.hasOption("date")) {
//			dateRef=Calendar.getInstance(Locale.FRANCE);
//			dateRef.setTime(dateformat.parse(cl.getOptionValue("date")));
//		}
//		croisementServiceBean.setDateReferentiel(dateRef);
		croisementServiceBean.setInclureDeclass(cl.hasOption("declassement"));
		croisementServiceBean.setInclureDispEch(cl.hasOption("dispech"));
		croisementServiceBean.setInclureDOM(cl.hasOption("dom"));
		croisementServiceBean.setPloPR(cl.hasOption("plopr"));
		//--tol�rance abscisse
		Integer toleranceAbscisse = -1;
		if (cl.hasOption("toleranceAbscisse")) {
			toleranceAbscisse = Integer.valueOf(cl
					.getOptionValue("toleranceAbscisse"));
		}
		croisementServiceBean.setToleranceAbscisse(toleranceAbscisse);
		//--tol�rance projection
		Integer toleranceProjection = -1;
		if (cl.hasOption("toleranceProjection")) {
			toleranceProjection = Integer.valueOf(cl
					.getOptionValue("toleranceProjection"));
		}
		croisementServiceBean.setToleranceProj(toleranceProjection);
		if(cl.hasOption("typeLocalisationSortie")){
			croisementServiceBean.setTypeLocalisationSortie(cl.getOptionValue("typeLocalisationSortie"));
		}		
		String repertoire = cl.getOptionValue("repertoire");
		
		// Lots en entr�e
		List<LotEntreeServiceBean> listeLotsEntree = new ArrayList<LotEntreeServiceBean>();
		if(cl.hasOption("lotsentree")){
			for(String nomLot : cl.getOptionValue("lotsentree").split(";")){
				// lecture du fichier properties
				Properties proprietes = new Properties();
				File fichier = TestServiceReferentiel.ouvreFichier(nomLot+".properties", repertoire);
				FileInputStream fis = new FileInputStream(fichier);
				proprietes.load(fis);
				
				// Cr�ation du bean
				LotEntreeServiceBean lotEntree = new LotEntreeServiceBean();
				lotEntree.setTypeLocalisation(proprietes.getProperty("lotentree.localisation"));
				lotEntree.setPortee(proprietes.getProperty("lotentree.portee"));
				lotEntree.setRecouvrement(TestServiceReferentiel.readBooleanProperty(proprietes.getProperty("lotentree.recouvrement"), true));
				lotEntree.setContinuite(TestServiceReferentiel.readBooleanProperty(proprietes.getProperty("lotentree.continuite"),false));
				lotEntree.setInclureConcede(TestServiceReferentiel.readBooleanProperty(proprietes.getProperty("lotentree.concede"),false));
				lotEntree.setInclureDOM(TestServiceReferentiel.readBooleanProperty(proprietes.getProperty("lotentree.dom"),false));
				lotEntree.setInclureDispEch(TestServiceReferentiel.readBooleanProperty(proprietes.getProperty("lotentree.dispech"),false));
				lotEntree.setInclureDeclass(TestServiceReferentiel.readBooleanProperty(proprietes.getProperty("lotentree.declass"),false));
				File fichierFeor = TestServiceReferentiel.ouvreFichier(proprietes.getProperty("lotentree.chemin"), repertoire);
				lotEntree.setFeorXML(TestServiceReferentiel.readFile(fichierFeor));
				
				listeLotsEntree.add(lotEntree);
			}
		}
		croisementServiceBean.setLotsEntree(listeLotsEntree.toArray(new LotEntreeServiceBean[listeLotsEntree.size()]));
		
		// Lots publi�s
		List<DetailLotPublieServiceBean> listeLotsPublies = new ArrayList<DetailLotPublieServiceBean>();
		if(cl.hasOption("lotspublies")){
			for(String nomLot : cl.getOptionValue("lotspublies").split(";")){
				
				// lecture du fichier properties
				Properties proprietes = new Properties();
				File fichier = TestServiceReferentiel.ouvreFichier(nomLot+".properties", repertoire);
				FileInputStream fis = new FileInputStream(fichier);
				proprietes.load(fis);
				
				// cr�ation du bean
				DetailLotPublieServiceBean lotPublie = new DetailLotPublieServiceBean();
				String strdate = (String) proprietes.get("lotpublie.date");
				Calendar dateActu = Calendar.getInstance(Locale.FRANCE);
				dateActu.setTime(dateformat.parse(strdate));
//				lotPublie.setDateActualite(dateActu);
				String[] attributs = proprietes.getProperty("lotpublie.attributs").split(",");
				for(int i=0;i<attributs.length;i++){
					attributs[i] = attributs[i].trim();
				}
				lotPublie.setNomsAttributs(attributs);
				lotPublie.setNomThematique((String) proprietes.get("lotpublie.thematique"));
				listeLotsPublies.add(lotPublie);
			}
		}
		croisementServiceBean.setLotsPublies(listeLotsPublies.toArray(new DetailLotPublieServiceBean[listeLotsPublies.size()]));
		parametres.setParametres(croisementServiceBean);
		
		// URL
		String url = TestServiceReferentiel.SERVICE_URL;
		if (cl.hasOption("url")) {
			url = cl.getOptionValue("url");
		}

		// Appel au webservice
		ServiceReferentielServiceStub stub = new ServiceReferentielServiceStub(url);
		RetourServiceAsyncBean response = null;
		try {
			response = stub.startcroiser(parametres);
		} catch (RemoteException e) {
			throw e;
		}

		// R�cup�ration des messages
		if (response.getMessagesCSV() != null) {
			if (cl.hasOption("messages")) {
				TestServiceReferentiel.writeStringTofile(new File(cl.getOptionValue("messages")), response.getMessagesCSV());
			}
			else {
				TestServiceReferentiel.log.info(response.getMessagesCSV());
			}
		}
		
		// R�cup�ration du r�sultat
		if (response.getResultat() != null) {
			if (cl.hasOption("o")) {
				TestServiceReferentiel.writeStringTofile(new File(cl.getOptionValue("o")), response.getResultat());
			}
			else {
				TestServiceReferentiel.log.info(response.getResultat());
			}
		}
		System.out.println("Croisement effectu�.");
	}
	
	/**
	 * writeStringTofile.
	 * 
	 * @param file
	 *            nom du fichier.
	 * @param content
	 *            contenu � ecrire.
	 * @throws Exception
	 */
	public static void writeStringTofile(final File file, final String content)
			throws Exception {
		FileWriter writer;
		try {
			writer = new FileWriter(file);
			writer.write(content);
			writer.flush();
			writer.close();
		} catch (IOException e) {
			throw new Exception(e.getMessage(), e);
		}

	}

	/**
	 * lecture de fichier XML et retour sous forme de chaine.
	 * 
	 * @param file
	 *            le fichier .
	 * @return la chaine contenant le fichier XML.
	 */
	public static String readFile(final File file) {
		String result;
		try {
			FileReader reader = new FileReader(file);
			try {
				StringBuffer buffer = new StringBuffer();
				char[] cbuf = new char[2048];
				int len;
				while ((len = reader.read(cbuf)) > 0) {
					buffer.append(cbuf, 0, len);
				}
				result = buffer.toString();
			} finally {
				reader.close();
			}
		} catch (IOException e) {
			result = "";
		}
		return result;
	}
	
	/**
	 * M�thode qui tente de trouver un fichier.
	 * @param nom le nom du fichier.
	 * @param repertoire le r�pertoire sp�cifi� (peut �tre null).
	 * @return le fichier.
	 */
	private static File ouvreFichier(String nom, String repertoire){
		File fichier = new File(nom);
		if(!fichier.exists()){
			fichier = new File(repertoire+"\\"+nom);
		}
		return fichier;
	}
	
	/**
	 * M�thode qui retourne le bool�en lu dans un fichier properties.
	 * @param valeur la valeur lue.
	 * @param valeurParDefaut la valeur bool�enne par d�faut de la propri�t�.
	 * @return le valeur lue.
	 */
	private static boolean readBooleanProperty(String valeur, boolean valeurParDefaut){
		if(valeur.toLowerCase().equals("o")){
			return true;
		} else if(valeur.toLowerCase().equals("n")){
			return false;
		} else {
			return valeurParDefaut;
		}
	}
}


