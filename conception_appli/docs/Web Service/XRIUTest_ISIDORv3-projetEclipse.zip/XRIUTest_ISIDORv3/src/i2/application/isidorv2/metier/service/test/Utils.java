package i2.application.isidorv2.metier.service.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class Utils {
	
	
	
	/**
	 * @author remi.bouilly
	 * @param sDate
	 * @param sFormat
	 * @return
	 * @throws ParseException
	 */
	public static Date parseDate(String sDate, String sFormat) throws ParseException {
		SimpleDateFormat format = (SimpleDateFormat) DateFormat.getDateInstance(DateFormat.FULL, Locale.FRANCE);
		format.applyPattern(sFormat);
		format.setTimeZone(TimeZone.getDefault());
		String[] ss = TimeZone.getAvailableIDs();
		return format.parse(sDate);
	}
	
	/**
	 * writeStringTofile.
	 * 
	 * @param file
	 *            nom du fichier.
	 * @param content
	 *            contenu � ecrire.
	 * @throws Exception
	 */
	public static void writeStringTofile(final File file, final String content)
			throws Exception {
		FileWriter writer;
		try {
			writer = new FileWriter(file);
			writer.write(content);
			writer.flush();
			writer.close();
		} catch (IOException e) {
			throw new Exception(e.getMessage(), e);
		}

	}

	/**
	 * lecture de fichier XML et retour sous forme de chaine.
	 * 
	 * @param file
	 *            le fichier .
	 * @return la chaine contenant le fichier XML.
	 */
	public static String readFile(final File file) {
		
	    StringBuilder contentBuilder = new StringBuilder();
	    try (BufferedReader br = new BufferedReader(new FileReader(file)))
	    {
	 
	        String sCurrentLine;
	        while ((sCurrentLine = br.readLine()) != null)
	        {
	            contentBuilder.append(sCurrentLine).append("\n");
	        }
	    }
	    catch (IOException e)
	    {
	        e.printStackTrace();
	    }
	    return contentBuilder.toString();
	}
	
	/**
	 * M�thode qui tente de trouver un fichier.
	 * @param nom le nom du fichier.
	 * @param repertoire le r�pertoire sp�cifi� (peut �tre null).
	 * @return le fichier.
	 */
	private static File ouvreFichier(String nom, String repertoire){
		File fichier = new File(nom);
		if(!fichier.exists()){
			fichier = new File(repertoire+"\\"+nom);
		}
		return fichier;
	}
	
}
