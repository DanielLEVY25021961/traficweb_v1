package i2.application.isidorv2.metier.service.test;

import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncCallbackHandler;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroiserAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.Geocoder;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceStub;
import i2.application.isidorv2.metier.service.ServiceResult;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroisementServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroiserAsyncResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.DetailLotPublieServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocodageServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsyncResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.LotEntreeServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RetourServiceAsyncBean;

import java.io.File;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Classe exemple de mise en oeuvre du Web Service ISIDOR v3, m�thode "croisement".
 * @author remi.bouilly
 */
public class TestCroisement {
	
	/**
	 * LOG.
	 */
	static final Log log = LogFactory.getLog(TestCroisement.class);
	
	// URL d'acc�s au Web Service ISIDOR v3
	//private final static String url = "http://isidor3.e2.rie.gouv.fr/isidorv3/services/ServiceReferentielServiceAsync";
	//private final static String url = "http://isidor3-recette2.dtecitm.cerema.i2/isidorv3/services/ServiceReferentielServiceAsync";
	//private final static String url = "http://isidor.application.developpement-durable.gouv.fr/isidorv3/services/ServiceReferentielServiceAsync";
	private final static String url = "http://isidorv3.rct01.kleegroup.com/ISIDORV3-1.3.3/services/ServiceReferentielServiceAsync";
	public static void main(String[] args) throws Exception {

		// classe d'encapsulation du lot FEOR et des param�tres (requ�te)
		//Asynchrone
		CroiserAsync requeteCroisementAsync = new CroiserAsync();
		
		CroisementServiceBean croisementServiceBean = new CroisementServiceBean();
		
		//on prepare les parametres de l'interrogation
		croisementServiceBean.setCalculerGeometrie(true);
		croisementServiceBean.setCalculerLongueur(true);
		
		//--date r�f�rentiel
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dateRef = sdf.parse("2018-01-01 00:00:00");
		
		croisementServiceBean.setDateReferentiel(dateRef);
		croisementServiceBean.setInclureDeclass(false);
		croisementServiceBean.setInclureDispEch(false);
		croisementServiceBean.setInclureDOM(false);
		croisementServiceBean.setPloPR(true);
		//--tol�rance abscisse
		Integer toleranceAbscisse = -1;
		croisementServiceBean.setToleranceAbscisse(toleranceAbscisse);
		//--tol�rance projection
		Integer toleranceProjection = -1;
		croisementServiceBean.setToleranceProj(toleranceProjection);
		//localisation sortie
		croisementServiceBean.setTypeLocalisationSortie("PR");	
		
		//definition des thematiques a croiser
		DetailLotPublieServiceBean[] lotsPublies = new DetailLotPublieServiceBean[2];
		
		//Donnees en entree : accidents � croiser avec les donnees ISIDOR
		// ajout du lot FEOR dans la requ�te
		LotEntreeServiceBean[] lotsEntree = new LotEntreeServiceBean[1];
		LotEntreeServiceBean lotEntree = new LotEntreeServiceBean();
		// param�tres obligatoires pour un lot en entr�e
		lotEntree.setTypeLocalisation("PR");
		lotEntree.setPortee("ROUTE");
		// contenu FEOR du lot en entree
		lotEntree.setFeorXML("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"
    		+ "<feor:lotGPR "
    		+ " 	xsi:schemaLocation=\"http://setra.equipement.gouv.fr/schema/feor/v2.1/catalogue-gpr.xsd\" "
    		+ "		feor:version=\"2.1\""
    		+ "		xmlns:xs=\"http://www.w3.org/2001/XMLSchema\""
    		+ "		xmlns:feor=\"http://setra.equipement.gouv.fr/schema/feor/v2.1\""
    		+ "		xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
    		+ "		xmlns:meriu=\"http://setra.equipement.gouv.fr/schema/meriu/v2.1\""
    		+ "		xmlns:gml=\"http://www.opengis.net/gml\">"
    		+ "	<enTete dateDeProduction=\"2009-08-28\" producteurDuLot=\"SETRA\">"
    		+ "		<referentielRoutier modeleEchangeReferentiel=\"MERIU v2\" "
    		+ "							dateReferentiel=\"2015-01-01\"/>"
    		+ "		<proprietesGeographique codeEPSG=\"2154\"/>"
    		+ "	</enTete>"
    		+ "	<contenuDuLot>"
    		+ "		<feor:ws01 feor:id=\"1\">"
    		+ "			<feor:proprietesMetier></feor:proprietesMetier>"
    		+ "			<lateralisation cote=\"I\"/>"
    		+ "			<localisationReferentielPonctuelle route=\"N0010\">"
    		+ "				<localisation depPr=\"86\" concessionPr=\"N\" pr=\"62\" abs=\"150\"/>"
    		+ "			</localisationReferentielPonctuelle>"
    		+ "		</feor:ws01>"
    		+ "	</contenuDuLot>"
    		+ "</feor:lotGPR>");
		// ajout du lot dans les param�tres
		lotsEntree[0] = lotEntree;
		croisementServiceBean.setLotsEntree(lotsEntree);
		
		//thematique GVO
		Date dateLot1 = sdf.parse("2015-01-01 00:00:00");

		DetailLotPublieServiceBean lotPublie = new DetailLotPublieServiceBean();
		lotPublie.setNomThematique("SectionGestion");
		String[] attributs = { "gestionnaire" };
		lotPublie.setNomsAttributs(attributs);
		lotPublie.setDateActualite(dateLot1);
		lotsPublies[0] = lotPublie;
		
		//thematique profil en travers
		Date dateLot2 = sdf.parse("2017-01-01 00:00:00");
		
		lotPublie = new DetailLotPublieServiceBean();
		lotPublie.setNomThematique("ClasseProfilTrav");
		String[] attributs2 = { "profil", "largeurEntretenue" };
		lotPublie.setNomsAttributs(attributs2);
		lotPublie.setDateActualite(dateLot2);
		lotsPublies[1] = lotPublie;
		
		croisementServiceBean.setLotsPublies(lotsPublies);
		
		requeteCroisementAsync.setParametres(croisementServiceBean);
		
		// initialisation du "stub" Web Service (classe d'appel du Web Service)
		System.out.println("D�marrage croisement");
		ServiceReferentielServiceStub stub = new ServiceReferentielServiceStub(url);
		
		// Cr�ation du callback
		ServiceResult res = new ServiceResult();
		ServiceReferentielServiceAsyncCallbackHandler callback = new ServiceReferentielServiceAsyncCallbackHandler(
				res) {

		};

		// Appel au webservice
		RetourServiceAsyncBean response = null;
		
		
		
		try {
			stub.startcroiser(requeteCroisementAsync);
		} catch (RemoteException e) {
			throw e;
		}
		
		// boucle pour patienter en attendant la r�ponse du Web Service
		while (!((ServiceResult)callback.getClientData()).getFinished()) {
			Thread.sleep(100); // pause de 100 ms
		}

		// dans le cas o� le Web Service a retourn� une erreur, on traite l'exception
		// ici, pour l'exemple, on se content de lancer cette exception
		if (((ServiceResult)callback.getClientData()).getE() != null) {
			throw ((ServiceResult)callback.getClientData()).getE();

		}

		// r�cup�ration du r�sultat dans le cas normal
		if (((ServiceResult)callback.getClientData()).getResponse() != null) {
			// ici, pour l'exemple, on affiche dans la console le lot FEOR obtenu dans la r�ponse
			System.out.println(((ServiceResult)callback.getClientData()).getResponse());
			// on v�rifie qu'il n'y a pas de message
			System.out.println(((ServiceResult)callback.getClientData()).getResponse());
			System.out.println("Croisement effectu�.");
		}
		
		
	}
}