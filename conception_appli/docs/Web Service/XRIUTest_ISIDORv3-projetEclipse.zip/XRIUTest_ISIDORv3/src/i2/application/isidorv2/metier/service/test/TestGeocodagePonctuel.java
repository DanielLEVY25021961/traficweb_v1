package i2.application.isidorv2.metier.service.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocodageServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RetourServiceAsyncBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceStub;

import java.io.File;
import java.rmi.RemoteException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Classe de tests junit pour le geocodage d objets ponctuels
 * @author remi.bouilly
 *
 */
public class TestGeocodagePonctuel {
	
	private static File sc1_1objetPonctuelPLOnonTypePR;
	private static File sc1_1objetPonctuelPLOechangeur;
	private static File sc1_1objetPonctuelPLO;
	private static File sc1_1objetPonctuelPLOdroit;
	private static File sc1_1objetPonctuelPLOgauche;
	private static File sc1_1objetPonctuelPLOdroitVoie;
	private static File sc1_1objetPonctuelPLOgaucheVoie;
	private static File sc1_1objetPonctuelPRdroit;
	private static File sc1_1objetPonctuelPRgauche;
	private static File sc1_1objetPonctuelPRdroitConcessionErronee;
	private static File sc1_1objetPonctuelXY;
	private static File sc1b_1objetPonctuelXY;
	private static File sc1c_1objetPonctuelXY;
	private static File sc1_1objetPonctuelPLOdroitAbsTropLongue;
	private static File sc1_10objetsPonctuelPLO;
	private static File sc1_1000objetsPonctuelPLO;
	private static File sc1_2objetsPonctuelsRecouvrement;
	private static File sc1b_2objetsPonctuelsRecouvrement;
	private static File sc1_1objetPonctuelPLOenErreur;
	private static File sc1_1objetPonctuelAccentsUTF_8;
	private static File sc1_1objetPonctuelAccentsISO_8859_1;
	private static File sc1_1objetPonctuelAbscisseNegativeEnDebutRoute;
	private static File sc1_1objetPonctuelPRgauche2corrections;

	private static final Log SLOG = LogFactory.getLog(TestGeocodagePonctuel.class);

	
	/**
	 * Configuration du service
	 */
	private final static String SERVICE_URL = "http://isidor3.e2.rie.gouv.fr/isidorv3/services/ServiceReferentielServiceAsync";
	
	private final static String DATE_REFERENTIEL_FORMAT = "DD/MM/yyyy";
	
	
	@BeforeClass
	public static void initilisationFichier() throws Exception {
		
		sc1_1objetPonctuelPLOnonTypePR = new File("target/classes/TR08-1/sc1_1objetPonctuelPLOnonTypePR.xml");
		if (!sc1_1objetPonctuelPLOnonTypePR.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPLOnonTypePR.getPath());

		sc1_1objetPonctuelPLOechangeur = new File("target/classes/TR08-1/sc1_1objetPonctuelPLOechangeur.xml");
		if (!sc1_1objetPonctuelPLOechangeur.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPLOechangeur.getPath());

		sc1_1objetPonctuelPLO = new File("target/classes/TR08-1/sc1_1objetPonctuelPLO.xml");
		if (!sc1_1objetPonctuelPLO.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPLO.getPath());
		
		sc1_1objetPonctuelPLOdroit = new File("target/classes/TR08-1/sc1_1objetPonctuelPLOdroit.xml");
		if (!sc1_1objetPonctuelPLOdroit.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPLOdroit.getPath());
		
		sc1_1objetPonctuelPLOgauche = new File("target/classes/TR08-1/sc1_1objetPonctuelPLOgauche.xml");
		if (!sc1_1objetPonctuelPLOgauche.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPLOgauche.getPath());

		sc1_1objetPonctuelPLOdroitVoie = new File("target/classes/TR08-1/sc1_1objetPonctuelPLOdroitVoie.xml");
		if (!sc1_1objetPonctuelPLOdroitVoie.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPLOdroitVoie.getPath());
		
		sc1_1objetPonctuelPLOgaucheVoie = new File("target/classes/TR08-1/sc1_1objetPonctuelPLOgaucheVoie.xml");
		if (!sc1_1objetPonctuelPLOgaucheVoie.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPLOgaucheVoie.getPath());

		sc1_1objetPonctuelPRdroit = new File("target/classes/TR08-1/sc1_1objetPonctuelPRdroit.xml");
		if (!sc1_1objetPonctuelPRdroit.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPRdroit.getPath());

		sc1_1objetPonctuelPRgauche = new File("target/classes/TR08-1/sc1_1objetPonctuelPRgauche.xml");
		if (!sc1_1objetPonctuelPRgauche.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPRgauche.getPath());

		sc1_1objetPonctuelPRdroitConcessionErronee = new File("target/classes/TR08-1/sc1_1objetPonctuelPRdroitConcessionErronee.xml");
		if (!sc1_1objetPonctuelPRdroitConcessionErronee.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPRdroitConcessionErronee.getPath());

		sc1_1objetPonctuelXY = new File("target/classes/TR08-1/sc1_1objetPonctuelXY.xml");
		if (!sc1_1objetPonctuelXY.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelXY.getPath());
		
		sc1b_1objetPonctuelXY = new File("target/classes/TR08-1/sc1b_1objetPonctuelXY.xml");
		if (!sc1b_1objetPonctuelXY.exists())
			throw new Exception("Fichier introuvable : " + sc1b_1objetPonctuelXY.getPath());
		
		sc1c_1objetPonctuelXY = new File("target/classes/TR08-1/sc1c_1objetPonctuelXY.xml");
		if (!sc1c_1objetPonctuelXY.exists())
			throw new Exception("Fichier introuvable : " + sc1c_1objetPonctuelXY.getPath());
		
		sc1_1objetPonctuelPLOdroitAbsTropLongue = new File("target/classes/TR08-1/sc1_1objetPonctuelPLOdroitAbsTropLongue.xml");
		if (!sc1_1objetPonctuelPLOdroitAbsTropLongue.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPLOdroitAbsTropLongue.getPath());
		
		sc1_10objetsPonctuelPLO = new File("target/classes/TR08-1/sc1_10objetsPonctuelPLO.xml");
		if (!sc1_10objetsPonctuelPLO.exists())
			throw new Exception("Fichier introuvable : " + sc1_10objetsPonctuelPLO.getPath());
		
		sc1_1000objetsPonctuelPLO = new File("target/classes/TR08-1/sc1_1000objetsPonctuelPLO.xml");
		if (!sc1_1000objetsPonctuelPLO.exists())
			throw new Exception("Fichier introuvable : " + sc1_1000objetsPonctuelPLO.getPath());
		
		sc1_2objetsPonctuelsRecouvrement = new File("target/classes/TR08-1/sc1_2objetsPonctuelsRecouvrement.xml");
		if (!sc1_2objetsPonctuelsRecouvrement.exists())
			throw new Exception("Fichier introuvable : " + sc1_2objetsPonctuelsRecouvrement.getPath());
		
		sc1b_2objetsPonctuelsRecouvrement = new File("target/classes/TR08-1/sc1b_2objetsPonctuelsRecouvrement.xml");
		if (!sc1b_2objetsPonctuelsRecouvrement.exists())
			throw new Exception("Fichier introuvable : " + sc1b_2objetsPonctuelsRecouvrement.getPath());
		
		sc1_1objetPonctuelPLOenErreur = new File("target/classes/TR08-1/sc1_1objetPonctuelPLOenErreur.xml");
		if (!sc1_1objetPonctuelPLOenErreur.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPLOenErreur.getPath());
		
		sc1_1objetPonctuelAccentsUTF_8 = new File("target/classes/TR08-1/sc1_1objetPonctuelAccentsUTF_8.xml");
		if (!sc1_1objetPonctuelAccentsUTF_8.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelAccentsUTF_8.getPath());
		
		sc1_1objetPonctuelAccentsISO_8859_1 = new File("target/classes/TR08-1/sc1_1objetPonctuelAccentsISO_8859_1.xml");
		if (!sc1_1objetPonctuelAccentsISO_8859_1.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelAccentsISO_8859_1.getPath());
		
		sc1_1objetPonctuelAbscisseNegativeEnDebutRoute = new File("target/classes/TR08-1/sc1_1objetPonctuelAbscisseNegativeEnDebutRoute.xml");
		if (!sc1_1objetPonctuelAbscisseNegativeEnDebutRoute.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelAbscisseNegativeEnDebutRoute.getPath());
		
		sc1_1objetPonctuelPRgauche2corrections = new File("target/classes/TR08-1/sc1_1objetPonctuelPRgauche2corrections.xml");
		if (!sc1_1objetPonctuelPRgauche2corrections.exists())
			throw new Exception("Fichier introuvable : " + sc1_1objetPonctuelPRgauche2corrections.getPath());
	
	}
	
	@Test
	public void testLocPLOnonTypePR() throws Exception {
		// classe d'encapsulation du lot FEOR et des param�tres (requ�te)
		//Asynchrone
		GeocoderAsync requeteAsync = new GeocoderAsync();
		requeteAsync.setFeorXml(Utils.readFile(sc1_1objetPonctuelPLOnonTypePR));
		requeteAsync.setParametres(new GeocodageServiceBean());
		requeteAsync.getParametres().setPortee("CHAUSSEE");
		requeteAsync.getParametres().setTypeLocalisation("PLO");
		
		ServiceReferentielServiceStub stub = new ServiceReferentielServiceStub(SERVICE_URL);
		RetourServiceAsyncBean serviceResult = null;
		try {
			serviceResult = stub.startgeocoder(requeteAsync);
		} catch (RemoteException e) {
			throw e;
		}
		if (serviceResult.getResultat() != null) {
			SLOG.info(serviceResult.getResultat());
			}
		
		assertEquals("Nb d'objets incorrect", 1, StringUtils.countMatches(serviceResult.getResultat(), "<feor:ws01"));
		assertTrue("<erreur> non pr�vue : " + serviceResult.getResultat(), serviceResult.getResultat().contains("<erreurs></erreurs>"));
		assertTrue("<correction> non pr�vue : " + serviceResult.getResultat(), serviceResult.getResultat().contains("<corrections></corrections>"));
		assertTrue("PLO erron�", serviceResult.getResultat().contains("plo=\"D_N0010_86_15D\""));
		assertTrue("abs erron�e", serviceResult.getResultat().contains("abs=\"150.0\""));
		assertTrue("abs cumul�e erron�e", serviceResult.getResultat().contains("cumul=\"147736.0\""));
	}

}
