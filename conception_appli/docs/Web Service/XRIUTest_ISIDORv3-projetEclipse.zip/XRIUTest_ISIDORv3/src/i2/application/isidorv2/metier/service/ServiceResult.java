package i2.application.isidorv2.metier.service;

import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RetourServiceAsyncBean;

/**
 * Classe appel�e par les callback du webservice.
 * 
 * @author JUFEBURI.
 *
 */
public class ServiceResult {

	/**
	 * Exception.
	 */
	private Exception e;

	private RetourServiceAsyncBean response;

	/**
	 * 
	 * @return
	 */
	public RetourServiceAsyncBean getResponse() {
		return response;
	}

	/**
	 * 
	 * @param result
	 */
	public void setResponse(RetourServiceAsyncBean response) {
		this.response = response;
	}

	/**
	 * @return the e
	 */
	public Exception getE() {
		return e;
	}

	/**
	 * @param e
	 *            the e to set
	 */
	public void setE(Exception e) {
		this.e = e;
	}	

	/**
	 * @return the finished
	 */
	public Boolean getFinished() {
		return this.e != null || this.response != null;
	}
	
	/**
	 * Nettoyage de l'objet.
	 */
	public void clear(){
		this.e = null;
		this.response = null;
	}

}
