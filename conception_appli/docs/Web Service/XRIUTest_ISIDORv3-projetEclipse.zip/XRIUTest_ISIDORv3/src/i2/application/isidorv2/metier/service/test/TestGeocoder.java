package i2.application.isidorv2.metier.service.test;

import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncCallbackHandler;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.Geocoder;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceStub;
import i2.application.isidorv2.metier.service.ServiceResult;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocodageServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsyncResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RetourServiceAsyncBean;

import java.io.File;
import java.rmi.RemoteException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Classe exemple de mise en oeuvre du Web Service ISIDOR v3, m�thode "g�ocoder".
 * @author remi.bouilly
 */
public class TestGeocoder {
	
	/**
	 * LOG.
	 */
	private static final Log log = LogFactory.getLog(TestGeocoder.class);
	
	// URL d'acc�s au Web Service ISIDOR v3
	//private final static String url = "http://isidor3-recette2.dtecitm.cerema.i2/isidorv3/services/ServiceReferentielServiceAsync";
	//private final static String url = "http://isidorv2.rct01.kleegroup.com/ISIDORV3-1.2/services/ServiceReferentielServiceAsync";
	//private final static String url = "http://isidor3.e2.rie.gouv.fr/isidorv3/services/ServiceReferentielServiceAsync";
	private final static String url = "http://isidorv3.rct01.kleegroup.com/ISIDORV3-1.3.3/services/ServiceReferentielServiceAsync";
	//private final static String url = "http://isidor.application.developpement-durable.gouv.fr/isidorv3/services/ServiceReferentielServiceAsync";
	
	public static void main(String[] args) throws Exception {

		// classe d'encapsulation du lot FEOR et des param�tres (requ�te)
		//Asynchrone
		GeocoderAsync requeteAsync = new GeocoderAsync();
		
		//Synchrone
		Geocoder requeteSync = new Geocoder();

		// ajout du lot FEOR dans la requ�te (en pratique, cette cha�ne sera calcul�e dynamiquement)
		File pFichier = new File("target/classes/TR08-1/sc1_1objetPonctuelPLOnonTypePR.xml");
		requeteAsync.setFeorXml(Utils.readFile(pFichier));
		requeteAsync.setFeorXml("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"
    		+ "<feor:lotGPR "
    		+ " 	xsi:schemaLocation=\"http://setra.equipement.gouv.fr/schema/feor/v2.1/catalogue-gpr.xsd\" "
    		+ "		feor:version=\"2.1\""
    		+ "		xmlns:xs=\"http://www.w3.org/2001/XMLSchema\""
    		+ "		xmlns:feor=\"http://setra.equipement.gouv.fr/schema/feor/v2.1\""
    		+ "		xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
    		+ "		xmlns:meriu=\"http://setra.equipement.gouv.fr/schema/meriu/v2.1\""
    		+ "		xmlns:gml=\"http://www.opengis.net/gml\">"
    		+ "	<enTete dateDeProduction=\"2009-08-28\" producteurDuLot=\"SETRA\">"
    		+ "		<referentielRoutier modeleEchangeReferentiel=\"MERIU v2\" "
    		+ "							dateReferentiel=\"2008-01-01\"/>"
    		+ "		<proprietesGeographique codeEPSG=\"2154\"/>"
    		+ "	</enTete>"
    		+ "	<contenuDuLot>"
    		+ "		<feor:ws01 feor:id=\"1\">"
    		+ "			<feor:proprietesMetier></feor:proprietesMetier>"
    		+ "			<lateralisation cote=\"I\"/>"
    		+ "			<localisationReferentielPonctuelle route=\"N0010\">"
    		+ "				<localisation depPr=\"86\" concessionPr=\"N\" pr=\"62\" abs=\"150\"/>"
    		+ "			</localisationReferentielPonctuelle>"
    		+ "		</feor:ws01>"
    		+ "	</contenuDuLot>"
    		+ "</feor:lotGPR>");
		
		// d�finition des param�tres de la requ�te
		requeteAsync.setParametres(new GeocodageServiceBean());
		requeteAsync.getParametres().setTypeLocalisation("PR");
		requeteAsync.getParametres().setCalculerGeometrie(true);
		requeteAsync.getParametres().setCalculerLongueur(true);
		requeteAsync.getParametres().setContinuite(false);
		requeteAsync.getParametres().setInclureDispEch(false);
		requeteAsync.getParametres().setInclureDOM(false);
		requeteAsync.getParametres().setPloPR(true);
		requeteAsync.getParametres().setPortee("CHAUSSEE");
		requeteAsync.getParametres().setRecouvrement(false);
		requeteAsync.getParametres().setToleranceAbscisse(10); //exemple : 10m
		requeteAsync.getParametres().setToleranceProjection(100);//exemple : 100m
		requeteAsync.getParametres().setTypeLocalisationSortie("PLO");
		
		// initialisation du "stub" Web Service (classe d'appel du Web Service)
		System.out.println("D�marrage g�ocodage");
		ServiceReferentielServiceStub stub = new ServiceReferentielServiceStub(url);
		RetourServiceAsyncBean response = null;
		try {
			response = stub.startgeocoder(requeteAsync);
		} catch (RemoteException e) {
			throw e;
		}
		if (response.getResultat() != null) {
			log.info(response.getResultat());
			Utils.writeStringTofile(new File("Geocoder_FEOR_reponse.xml"), response.getResultat());
			}
		System.out.println("G�ocodage effectu�");
		
	}
}