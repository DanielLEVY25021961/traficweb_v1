
/**
 * ServiceReferentielServiceAsyncCallbackHandler.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.6  Built on : Aug 30, 2011 (10:00:16 CEST)
 */

    package i2.application.isidorv2.metier.service;

    /**
     *  ServiceReferentielServiceAsyncCallbackHandler Callback class, Users can extend this class and implement
     *  their own receiveResult and receiveError methods.
     */
    public abstract class ServiceReferentielServiceAsyncCallbackHandler{



    protected Object clientData;

    /**
    * User can pass in any object that needs to be accessed once the NonBlocking
    * Web service call is finished and appropriate method of this CallBack is called.
    * @param clientData Object mechanism by which the user can pass in user data
    * that will be avilable at the time this callback is called.
    */
    public ServiceReferentielServiceAsyncCallbackHandler(Object clientData){
        this.clientData = clientData;
    }

    /**
    * Please use this constructor if you don't want to set any clientData
    */
    public ServiceReferentielServiceAsyncCallbackHandler(){
        this.clientData = null;
    }

    /**
     * Get the client data
     */

     public Object getClientData() {
        return clientData;
     }

        
           /**
            * auto generated Axis2 call back method for recalerCheckResult method
            * override this method for handling normal response from recalerCheckResult operation
            */
           public void receiveResultrecalerCheckResult(
                    i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalerCheckResultResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from recalerCheckResult operation
           */
            public void receiveErrorrecalerCheckResult(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for croiserAsync method
            * override this method for handling normal response from croiserAsync operation
            */
           public void receiveResultcroiserAsync(
                    i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroiserAsyncResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from croiserAsync operation
           */
            public void receiveErrorcroiserAsync(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for croiserCheckResult method
            * override this method for handling normal response from croiserCheckResult operation
            */
           public void receiveResultcroiserCheckResult(
                    i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroiserCheckResultResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from croiserCheckResult operation
           */
            public void receiveErrorcroiserCheckResult(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for interrogerDonneesAsync method
            * override this method for handling normal response from interrogerDonneesAsync operation
            */
           public void receiveResultinterrogerDonneesAsync(
                    i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesAsyncResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from interrogerDonneesAsync operation
           */
            public void receiveErrorinterrogerDonneesAsync(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for recalerAsync method
            * override this method for handling normal response from recalerAsync operation
            */
           public void receiveResultrecalerAsync(
                    i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalerAsyncResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from recalerAsync operation
           */
            public void receiveErrorrecalerAsync(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for geocoderAsync method
            * override this method for handling normal response from geocoderAsync operation
            */
           public void receiveResultgeocoderAsync(
                    i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsyncResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from geocoderAsync operation
           */
            public void receiveErrorgeocoderAsync(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for geocoderCheckResult method
            * override this method for handling normal response from geocoderCheckResult operation
            */
           public void receiveResultgeocoderCheckResult(
                    i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderCheckResultResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from geocoderCheckResult operation
           */
            public void receiveErrorgeocoderCheckResult(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for interrogerDonneesCheckResult method
            * override this method for handling normal response from interrogerDonneesCheckResult operation
            */
           public void receiveResultinterrogerDonneesCheckResult(
                    i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesCheckResultResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from interrogerDonneesCheckResult operation
           */
            public void receiveErrorinterrogerDonneesCheckResult(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for geocoder method
            * override this method for handling normal response from geocoder operation
            */
           public void receiveResultgeocoder(
                    i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from geocoder operation
           */
            public void receiveErrorgeocoder(java.lang.Exception e) {
            }
                


    }
    