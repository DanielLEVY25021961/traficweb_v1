/**
 * 
 */
package i2.application.isidorv2.metier.service;

import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroiserAsyncResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroiserCheckResultResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsyncResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderCheckResultResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesAsyncResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesCheckResultResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalerAsyncResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalerCheckResultResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RetourServiceAsyncBean;

/**
 * @author JUFEBURI
 *
 */
public class ServiceReferentielServiceAsyncCallbackHandlerImpl extends ServiceReferentielServiceAsyncCallbackHandler{

	public ServiceReferentielServiceAsyncCallbackHandlerImpl(Object clientData){
		super(clientData);
	}
	
	/**
	 * 
	 * @param retour
	 */
	private void setResult(RetourServiceAsyncBean retour) {
		ServiceResult result = (ServiceResult) this.clientData;
		result.clear();
		result.setResponse(retour);
	}
	
	/**
	 * 
	 * @param e
	 */
	private void setException(Exception e) {
		ServiceResult result = (ServiceResult) this.clientData;
		result.clear();
		result.setE(e);
	}
	
	@Override
	public void receiveErrorcroiserAsync(Exception e) {
		this.setException(e);
		super.receiveErrorcroiserAsync(e);
	}
	@Override
	public void receiveResultcroiserAsync(CroiserAsyncResponse result) {
		this.setResult(result.get_return());
		super.receiveResultcroiserAsync(result);
	}
	
	@Override
	public void receiveErrorcroiserCheckResult(Exception e) {
		this.setException(e);
		super.receiveErrorcroiserCheckResult(e);
	}
	
	@Override
	public void receiveResultcroiserCheckResult(CroiserCheckResultResponse result) {
		this.setResult(result.get_return());
		super.receiveResultcroiserCheckResult(result);
	}
	
	@Override
	public void receiveErrorgeocoderAsync(Exception e) {
		this.setException(e);
		super.receiveErrorgeocoderAsync(e);
	}
	@Override
	public void receiveResultgeocoderAsync(GeocoderAsyncResponse result) {
		this.setResult(result.get_return());
		super.receiveResultgeocoderAsync(result);
	}
	
	@Override
	public void receiveErrorgeocoderCheckResult(Exception e) {
		this.setException(e);
		super.receiveErrorgeocoderCheckResult(e);
	}
	
	@Override
	public void receiveResultgeocoderCheckResult(GeocoderCheckResultResponse result) {
		this.setResult(result.get_return());
		super.receiveResultgeocoderCheckResult(result);
	}
	
	@Override
	public void receiveErrorrecalerAsync(Exception e) {
		this.setException(e);
		super.receiveErrorrecalerAsync(e);
	}
	
	@Override
	public void receiveResultrecalerAsync(RecalerAsyncResponse result) {
		this.setResult(result.get_return());
		super.receiveResultrecalerAsync(result);
	}
	
	@Override
	public void receiveErrorrecalerCheckResult(Exception e) {
		this.setException(e);
		super.receiveErrorrecalerCheckResult(e);
	}
	
	@Override
	public void receiveResultrecalerCheckResult(RecalerCheckResultResponse result) {
		this.setResult(result.get_return());
		super.receiveResultrecalerCheckResult(result);
	}
	
	@Override
	public void receiveErrorinterrogerDonneesAsync(Exception e) {
		this.setException(e);
		super.receiveErrorinterrogerDonneesAsync(e);
	}
	
	@Override
	public void receiveResultinterrogerDonneesAsync(InterrogerDonneesAsyncResponse result) {
		this.setResult(result.get_return());
		super.receiveResultinterrogerDonneesAsync(result);
	}
	
	@Override
	public void receiveErrorinterrogerDonneesCheckResult(Exception e) {
		this.setException(e);
		super.receiveErrorinterrogerDonneesCheckResult(e);
	}
	
	@Override
	public void receiveResultinterrogerDonneesCheckResult(InterrogerDonneesCheckResultResponse result) {
		this.setResult(result.get_return());
		super.receiveResultinterrogerDonneesCheckResult(result);
	}
	
	
}
