package i2.application.isidorv2.metier.service.test;

import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncCallbackHandler;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.Geocoder;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceStub;
import i2.application.isidorv2.metier.service.ServiceResult;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.FiltreAttributServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocodageServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsyncResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RetourServiceAsyncBean;

import java.io.File;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Classe exemple de mise en oeuvre du Web Service ISIDOR v3, m�thode "interrogation".
 * @author remi.bouilly
 */
public class TestInterrogation {
	
	/**
	 * LOG.
	 */
	private static final Log log = LogFactory.getLog(TestInterrogation.class);
	
	// URL d'acc�s au Web Service ISIDOR v3
	//URL PLATEFORME RECETTE INTRANET
	//private final static String SERVICE_URL = "http://isidor3-recette2.dtecitm.cerema.i2/isidorv3/services/ServiceReferentielServiceAsync";
	//URL PLATEFORME KLEE INTERNET
	//private final static String SERVICE_URL = "http://isidorv3.rct01.kleegroup.com/ISIDORV3-1.3.3/services/ServiceReferentielServiceAsync";
	//URL PLATEFORME RECETTE INTERNET
	private final static String SERVICE_URL = "http://isidor.application.developpement-durable.gouv.fr/isidorv3/services/ServiceReferentielServiceAsync";
	
	
	public static void main(String[] args) throws Exception {

		// classe d'encapsulation du lot FEOR et des param�tres (requ�te)
		InterrogerDonneesAsync requeteInterrogationAsync = new InterrogerDonneesAsync();
		
		//on prepare les parametres de l'interrogation
		requeteInterrogationAsync.setParametres(new InterrogerDonneesServiceBean());

		requeteInterrogationAsync.getParametres().setMetadonnees(false);
		requeteInterrogationAsync.getParametres().setNomThematique("ClasseProfilTravSectionnee");
		requeteInterrogationAsync.getParametres().setTypeLocalisation("PR");
		
		//date du lot a recuperer
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//Date date = sdf.parse("2016-01-01 00:00:00");
		//requeteInterrogationAsync.getParametres().setDateActualite(date);
		
		//ajout filtre sur la route
		FiltreAttributServiceBean filtreRoute = new FiltreAttributServiceBean();
		filtreRoute.setNomAttribut("nomRoute");
		filtreRoute.setOperateur("EGAL_A");
		filtreRoute.setOperandes(new String[] {"A0001"});
		
		//ajout filtre sur le gestionnaire
//		FiltreAttributServiceBean filtreGestion = new FiltreAttributServiceBean();
//		filtreGestion.setNomAttribut("sectionnement_gestionnaire");
//		filtreGestion.setOperateur("EGAL_A");
//		filtreGestion.setOperandes(new String[] {"DIRIF"});
//		FiltreAttributServiceBean[] filtresGeneriques = new FiltreAttributServiceBean[] {filtreRoute};
		
		//ajout filtre sur la localisation
		//localisation PLO d�but
		FiltreAttributServiceBean filtrePloDebut = new FiltreAttributServiceBean();
		filtrePloDebut.setNomAttribut("ploDebut");
		filtrePloDebut.setOperateur("EGAL_A");
		filtrePloDebut.setOperandes(new String[] {"93PR2D"});
		//localisation PLO fin
		FiltreAttributServiceBean filtrePloFin = new FiltreAttributServiceBean();
		filtrePloFin.setNomAttribut("ploFin");
		filtrePloFin.setOperateur("EGAL_A");
		filtrePloFin.setOperandes(new String[] {"93PR2D"});
		
		FiltreAttributServiceBean[] filtresGeneriques = new FiltreAttributServiceBean[] {filtreRoute, filtrePloDebut, filtrePloFin};
		//FiltreAttributServiceBean[] filtresMetiers = new FiltreAttributServiceBean[] {filtreGestion};
		requeteInterrogationAsync.getParametres().setFiltresAttributGenerique(filtresGeneriques);
		//parametres.getParametres().setFiltresAttributMetier(filtresMetiers);
		
		//parametres.getParametres().setCouverture(new String[] {"NON_CONCEDE"});
		
		// initialisation du "stub" Web Service (classe d'appel du Web Service)
		System.out.println("D�marrage interrogation");
		String url = TestInterrogation.SERVICE_URL;
		ServiceReferentielServiceStub stub = new ServiceReferentielServiceStub(url);
		RetourServiceAsyncBean response = null;
		try {
			response = stub.startInterrogerDonnees(requeteInterrogationAsync);
		} catch (RemoteException e) {
			throw e;
		}
		
		if (response.getResultat() != null) {
			TestServiceReferentiel.log.info(response.getResultat());
			Utils.writeStringTofile(new File("Interroger_FEOR_reponse.xml"), response.getResultat());
		}
		System.out.println("Interrogation effectu�e.");
		
	}
}