/**
 * 
 */
package i2.application.isidorv2.metier.service;

import java.rmi.RemoteException;

import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroiserAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.CroiserCheckResult;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderCheckResult;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.InterrogerDonneesCheckResult;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalerAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalerCheckResult;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RetourServiceAsyncBean;

/**
 * @author JUFEBURI
 * @Date 13/04/2011
 *
 */
public class ServiceReferentielServiceStub {
	
	/**
	 * Temps de la boucle pour l'attente de la r�ponse d'un appel, en millisecondes.
	 */
	public static final int TEMPS_ATTENTE_REPONSE = 100;
	
	/**
	 * Temps du timeout de la requ�te, en millisecondes.
	 */
	public static final int TEMPS_ATTENTE_REPONSE_MAX = 120000;
	
	/**
	 * Temps attendu entre chaque appel par polling, en millisecondes.
	 */
	private static final int TEMPS_POLLING = 5000;
	
	/**
	 * L'URL du webservice.
	 */
	private String url;
	
	/**
	 * Constructeur.
	 * @param url l'URL du webservice.
	 */
	public ServiceReferentielServiceStub(String url){
		this.url = url;
	}
	
	/**
	 * 
	 * @param url
	 * @return
	 */
	private ServiceReferentielServiceAsyncStub getNewServiceStub(String url) throws Exception {
		ServiceReferentielServiceAsyncStub stub = new ServiceReferentielServiceAsyncStub(url);
		stub._getServiceClient().getOptions().setTimeOutInMilliSeconds(ServiceReferentielServiceStub.TEMPS_ATTENTE_REPONSE_MAX);
		stub._getServiceClient().getOptions().setProperty(org.apache.axis2.transport.http.HTTPConstants.HTTP_PROTOCOL_VERSION, org.apache.axis2.transport.http.HTTPConstants.HEADER_PROTOCOL_10);
		return stub;
	}
	
	/**
	 * M�thode d'appel de la m�thode de croisement du webservice.
	 * @param croiserAsync les param�tres du croisement.
	 * @param callback le callback de r�ception du r�sultat.
	 * @return le retour du croisement.
	 * @throws Exception si erreur.
	 */
	public RetourServiceAsyncBean startcroiser(CroiserAsync croiserAsync) throws Exception {
		
		// Cr�ation du callback
		ServiceResult res = new ServiceResult();
		ServiceReferentielServiceAsyncCallbackHandlerImpl callbackStub = new ServiceReferentielServiceAsyncCallbackHandlerImpl(res);
		
		// Appel au webservice
		ServiceReferentielServiceAsyncStub stub = this.getNewServiceStub(this.url);
		try {
			stub.startcroiserAsync(croiserAsync, callbackStub);
		} catch (RemoteException e) {
			throw e;
		}
		while (!res.getFinished()) {
			Thread.sleep(ServiceReferentielServiceStub.TEMPS_ATTENTE_REPONSE);
		}

		// G�n�ration des exceptions
		if (res.getE() != null) {
			throw res.getE();
		}
		
		//Si le traitement n'est pas termin� : polling
		CroiserCheckResult croiserCheckResult = new CroiserCheckResult();
		croiserCheckResult.setIdTraitement(res.getResponse().getIdTraitement());
		
		while(res.getResponse().getStatut().equals("En cours")){
			// Attente
			Thread.sleep(ServiceReferentielServiceStub.TEMPS_POLLING);
			
			// Renvoi de la demande
			res.clear();
			try {
				stub.startcroiserCheckResult(croiserCheckResult, callbackStub);
			} catch (RemoteException e) {
				throw e;
			}
			while (!res.getFinished()) {
				Thread.sleep(ServiceReferentielServiceStub.TEMPS_ATTENTE_REPONSE);
			}

			// G�n�ration des exceptions
			if (res.getE() != null) {
				throw res.getE();
			}
		}
		
		return res.getResponse();
	}
	
	/**
	 * M�thode d'appel de la m�thode de g�ocodage du webservice.
	 * @param geocoderAsync les param�tres du g�ocodage.
	 * @param callback le callback de r�ception du r�sultat.
	 * @return le retour du g�ocodage.
	 * @throws Exception si erreur.
	 */
	public RetourServiceAsyncBean startgeocoder(GeocoderAsync geocoderAsync) throws Exception {
		// Cr�ation du callback
		ServiceResult res = new ServiceResult();
		ServiceReferentielServiceAsyncCallbackHandlerImpl callbackStub = new ServiceReferentielServiceAsyncCallbackHandlerImpl(res);
		
		
		// Appel au webservice
		ServiceReferentielServiceAsyncStub stub = this.getNewServiceStub(this.url);
		try {
			stub.startgeocoderAsync(geocoderAsync, callbackStub);
		} catch (RemoteException e) {
			throw e;
		}
		while (!res.getFinished()) {
			Thread.sleep(ServiceReferentielServiceStub.TEMPS_ATTENTE_REPONSE);
		}

		// G�n�ration des exceptions
		if (res.getE() != null) {
			throw res.getE();
		}
		
		//Si le traitement n'est pas termin� : polling
		GeocoderCheckResult geocoderCheckResult = new GeocoderCheckResult();
		geocoderCheckResult.setIdTraitement(res.getResponse().getIdTraitement());
		
		while(res.getResponse().getStatut().equals("En cours")){
			Thread.sleep(ServiceReferentielServiceStub.TEMPS_POLLING);
			res.clear();
			try {
				stub.startgeocoderCheckResult(geocoderCheckResult, callbackStub);
			} catch (RemoteException e) {
				throw e;
			}
			while (!res.getFinished()) {
				Thread.sleep(ServiceReferentielServiceStub.TEMPS_ATTENTE_REPONSE);
			}

			// G�n�ration des exceptions
			if (res.getE() != null) {
				throw res.getE();
			}			
		}
		
		return res.getResponse();
	}
	
	/**
	 * M�thode d'appel de la m�thode de recalage du webservice.
	 * @param recalerAsync les param�tres du recalage.
	 * @param callback le callback de r�ception du r�sultat.
	 * @return le retour du recalage.
	 * @throws Exception si erreur.
	 */
	public RetourServiceAsyncBean startrecaler(RecalerAsync recalerAsync) throws Exception {
		// Cr�ation du callback
		ServiceResult res = new ServiceResult();
		ServiceReferentielServiceAsyncCallbackHandlerImpl callbackStub = new ServiceReferentielServiceAsyncCallbackHandlerImpl(res);
		
		
		// Appel au webservice
		ServiceReferentielServiceAsyncStub stub = this.getNewServiceStub(this.url);
		try {
			stub.startrecalerAsync(recalerAsync, callbackStub);
		} catch (RemoteException e) {
			throw e;
		}
		while (!res.getFinished()) {
			Thread.sleep(ServiceReferentielServiceStub.TEMPS_ATTENTE_REPONSE);
		}

		// G�n�ration des exceptions
		if (res.getE() != null) {
			throw res.getE();
		}
		
		//Si le traitement n'est pas termin� : polling
		RecalerCheckResult recalerCheckResult = new RecalerCheckResult();
		recalerCheckResult.setIdTraitement(res.getResponse().getIdTraitement());
		
		while(res.getResponse().getStatut().equals("En cours")){
			Thread.sleep(ServiceReferentielServiceStub.TEMPS_POLLING);
			res.clear();
			try {
				stub.startrecalerCheckResult(recalerCheckResult, callbackStub);
			} catch (RemoteException e) {
				throw e;
			}
			while (!res.getFinished()) {
				Thread.sleep(ServiceReferentielServiceStub.TEMPS_ATTENTE_REPONSE);
			}

			// G�n�ration des exceptions
			if (res.getE() != null) {
				throw res.getE();
			}			
		}
		
		return res.getResponse();
	}
	
	public RetourServiceAsyncBean startInterrogerDonnees(InterrogerDonneesAsync interrogerDonneesAsync) throws Exception {
		// Cr�ation du callback
		ServiceResult res = new ServiceResult();
		ServiceReferentielServiceAsyncCallbackHandlerImpl callbackStub = new ServiceReferentielServiceAsyncCallbackHandlerImpl(res);
		
		
		// Appel au webservice
		ServiceReferentielServiceAsyncStub stub = this.getNewServiceStub(this.url);
		try {
			stub.startinterrogerDonneesAsync(interrogerDonneesAsync, callbackStub);
		} catch (RemoteException e) {
			throw e;
		}
		while (!res.getFinished()) {
			Thread.sleep(ServiceReferentielServiceStub.TEMPS_ATTENTE_REPONSE);
		}

		// G�n�ration des exceptions
		if (res.getE() != null) {
			throw res.getE();
		}
		
		//Si le traitement n'est pas termin� : polling
		InterrogerDonneesCheckResult interrogerDonneesCheckResult = new InterrogerDonneesCheckResult();
		interrogerDonneesCheckResult.setIdTraitement(res.getResponse().getIdTraitement());
		
		while(res.getResponse().getStatut().equals("En cours")){
			Thread.sleep(ServiceReferentielServiceStub.TEMPS_POLLING);
			res.clear();
			try {
				stub.startinterrogerDonneesCheckResult(interrogerDonneesCheckResult, callbackStub);
			} catch (RemoteException e) {
				throw e;
			}
			while (!res.getFinished()) {
				Thread.sleep(ServiceReferentielServiceStub.TEMPS_ATTENTE_REPONSE);
			}

			// G�n�ration des exceptions
			if (res.getE() != null) {
				throw res.getE();
			}			
		}
		
		return res.getResponse();
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(final String url) {
		this.url = url;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return this.url;
	}
	
}
