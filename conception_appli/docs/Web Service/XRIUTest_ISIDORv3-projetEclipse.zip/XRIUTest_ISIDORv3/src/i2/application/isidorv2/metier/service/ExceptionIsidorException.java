
/**
 * ExceptionIsidorException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.6  Built on : Aug 30, 2011 (10:00:16 CEST)
 */

package i2.application.isidorv2.metier.service;

public class ExceptionIsidorException extends java.lang.Exception{
    
    private i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.ExceptionIsidorE faultMessage;

    
        public ExceptionIsidorException() {
            super("ExceptionIsidorException");
        }

        public ExceptionIsidorException(java.lang.String s) {
           super(s);
        }

        public ExceptionIsidorException(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public ExceptionIsidorException(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.ExceptionIsidorE msg){
       faultMessage = msg;
    }
    
    public i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.ExceptionIsidorE getFaultMessage(){
       return faultMessage;
    }
}
    