package i2.application.isidorv2.metier.service.test;

import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncCallbackHandler;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.Geocoder;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceStub;
import i2.application.isidorv2.metier.service.ServiceResult;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocodageServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.GeocoderAsyncResponse;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalageLotExterneServiceBean;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RecalerAsync;
import i2.application.isidorv2.metier.service.ServiceReferentielServiceAsyncStub.RetourServiceAsyncBean;

import java.io.File;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Classe exemple de mise en oeuvre du Web Service ISIDOR v3, m�thode "Recaler".
 * @author remi.bouilly
 */
public class TestRecaler {
	
	/**
	 * LOG.
	 */
	private static final Log log = LogFactory.getLog(TestRecaler.class);
	
	// URL d'acc�s au Web Service ISIDOR v3
	//private final static String url = "http://isidor3-recette2.dtecitm.cerema.i2/isidorv3/services/ServiceReferentielServiceAsync";
	//private final static String url = "http://isidor3.e2.rie.gouv.fr/isidorv3/services/ServiceReferentielServiceAsync";
	private final static String url = "http://isidorv3.rct01.kleegroup.com/ISIDORV3-1.3.3/services/ServiceReferentielServiceAsync";
	
	public static void main(String[] args) throws Exception {

		// classe d'encapsulation du lot FEOR et des param�tres (requ�te)
		//Asynchrone
		RecalerAsync requeteRecalerAsync = new RecalerAsync();

		// ajout du lot FEOR dans la requ�te (en pratique, cette cha�ne sera calcul�e dynamiquement)
		requeteRecalerAsync.setFeorXml("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"
    		+ "<feor:lotGPR "
    		+ " 	xsi:schemaLocation=\"http://setra.equipement.gouv.fr/schema/feor/v2.1/catalogue-gpr.xsd\" "
    		+ "		feor:version=\"2.1\""
    		+ "		xmlns:xs=\"http://www.w3.org/2001/XMLSchema\""
    		+ "		xmlns:feor=\"http://setra.equipement.gouv.fr/schema/feor/v2.1\""
    		+ "		xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
    		+ "		xmlns:meriu=\"http://setra.equipement.gouv.fr/schema/meriu/v2.1\""
    		+ "		xmlns:gml=\"http://www.opengis.net/gml\">"
    		+ "	<enTete dateDeProduction=\"2009-08-28\" producteurDuLot=\"SETRA\">"
    		+ "		<referentielRoutier modeleEchangeReferentiel=\"MERIU v2\" "
    		+ "							dateReferentiel=\"2008-01-01\"/>"
    		+ "		<proprietesGeographique codeEPSG=\"2154\"/>"
    		+ "	</enTete>"
    		+ "	<contenuDuLot>"
    		+ "		<feor:ws01 feor:id=\"1\">"
    		+ "			<feor:proprietesMetier></feor:proprietesMetier>"
    		+ "			<lateralisation cote=\"I\"/>"
    		+ "			<localisationReferentielPonctuelle route=\"N0010\">"
    		+ "				<localisation depPr=\"86\" concessionPr=\"N\" pr=\"62\" abs=\"150\"/>"
    		+ "			</localisationReferentielPonctuelle>"
    		+ "		</feor:ws01>"
    		+ "	</contenuDuLot>"
    		+ "</feor:lotGPR>");
		
		// d�finition des param�tres de la requ�te
		requeteRecalerAsync.setParametres(new RecalageLotExterneServiceBean());
		requeteRecalerAsync.getParametres().setPortee("CHAUSSEE");
		requeteRecalerAsync.getParametres().setLocalisation("PR");
		requeteRecalerAsync.getParametres().setCalculLocalisationComplementaires(true);
		
		//--date r�f�rentiel
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar referentielSource = null;
		Calendar referentielCible = null;
		referentielSource = Calendar.getInstance(Locale.FRANCE);
		referentielCible = Calendar.getInstance(Locale.FRANCE);
		String DATE_REFERENTIEL_FORMAT = "DD/MM/yyyy";
		referentielSource.setTime(Utils.parseDate("01/01/2008", DATE_REFERENTIEL_FORMAT));
		referentielCible.setTime(Utils.parseDate("01/01/2016", DATE_REFERENTIEL_FORMAT));
		
		requeteRecalerAsync.getParametres().setDateReferentielSource(referentielSource);
		requeteRecalerAsync.getParametres().setDateReferentielCible(referentielCible);
		
		// initialisation du "stub" Web Service (classe d'appel du Web Service)
		System.out.println("D�marrage recalage");
		ServiceReferentielServiceStub stub = new ServiceReferentielServiceStub(url);
		RetourServiceAsyncBean response = null;
		try {
			response = stub.startrecaler(requeteRecalerAsync);
		} catch (RemoteException e) {
			throw e;
		}
		if (response.getResultat() != null) {
			log.info(response.getResultat());
			Utils.writeStringTofile(new File("Recaler_FEOR_reponse.xml"), response.getResultat());
			}
		System.out.println("Recalage effectu�");
		
	}
}