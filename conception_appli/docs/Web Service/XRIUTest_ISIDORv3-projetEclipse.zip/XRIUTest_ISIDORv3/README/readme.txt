--------------------------------------------------------------------------------------------
--------------------- AIDE POUR L'UTILISATION DU CLIENT DE TEST XRIU ISIDOR v3------------------------
--------------------------------------------------------------------------------------------

********************************************************************************************
1. Choix de la fonction (croisement, g�ocodage, recalage, interrogation de donn�es)
********************************************************************************************
Le webservice r�f�rentiel comprend d�sormais 4 fonctions (croiser, geocoder, recalage, interrogation).
Le choix de l'une ou de l'autre de ces options s'effectue dans le premier argument pass� en 
param�tre ("croiser", "geocoder","recaler", ou "interroger" selon la fonction choisie). Les options qui suivent sont
celles de la fonction choisie.

Pour obtenir de l'aide sur les options d'une fonction : 
* croiser -h
* geocoder -h
* recaler -h
* interroger -h

********************************************************************************************
2. Webservice de g�ocodage
********************************************************************************************
usage: java -jar xriu.jar geocoder -f nom_fichier_xml -portee portee_lot
            -localisation type_localisation [-o fichier_sortie] [OPTIONS]
 -continuite                  Continuite (non)
 -dispech                     Inclure les dispositifs d'�changes (non)
 -dom                         Inclure les DOM/COM (non)
 -f <arg>                     Nom du fichier FEOR/XML
 -geom                        Calcul de la g�om�trie (non)
 -h                           Afficher l'aide
 -localisation <arg>          Type de localisation (PLO)/PR/XY
 -longueur                    Calcul de la longueur (non)
 -norecouvrement              Interdire les recouvrements
 -o <arg>                     nom du fichier de sortie
 -plopr                       PLO de type PR (non)
 -portee <arg>                Portee du lot ROUTE/VOIE/(CHAUSSEE)
 -toleranceAbscisse <arg>     Tolerance d'abscisse
 -toleranceProjection <arg>   Tolerance de projection
 -url <arg>                   Url d'acc�s au web service
 
********************************************************************************************
3. Webservice de croisement de donn�es
********************************************************************************************

usage: java -jar xriu.jar croiser -o fichier_sortie.xml -messages fichier_messages.csv 
                 [-lotspublies lot1;lot2;lot3] [-lotsentree lot4;lot5;lot6] [OPTIONS]
 -date <arg>                  Date du r�f�rentiel cible du croisement
                              (JJ/MM/AAAA)
 -declassement                Inclure les voies en cours de d�classement
                              (non)
 -dispech                     Inclure les dispositifs d'�changes (non)
 -dom                         Inclure les DOM/COM (non)
 -geom                        Calcul de la g�om�trie (non)
 -h                           Afficher l'aide
 -longueur                    Calcul de la longueur (non)
 -lotsentree <arg>            Noms des lots en entr�e (�quivalent au nom
                              des fichiers sans l'extension), s�par�s par
                              des points virgule, sans espaces
 -lotspublies <arg>           Noms des lots publi�s (�quivalent au nom des
                              fichiers sans l'extension), s�par�s par des
                              points virgule, sans espaces
 -messages <arg>              nom du fichier CSV de messages de sortie
 -o <arg>                     nom du fichier FEOR de sortie
 -plopr                       PLO de type PR (non)
 -repertoire <arg>            R�pertoire o� se situent les fichiers de
                              description des lots
 -toleranceAbscisse <arg>     Tolerance d'abscisse
 -toleranceProjection <arg>   Tolerance de projection
 -url <arg>                   Url d'acc�s au web service

Les options du croisement sont � entrer simplement dans la ligne de commande.
Les descriptions des lots publi�s choisis et de leurs attributs, ainsi que des lots en 
entr�e avec leurs options d'import sont d�crites dans des fichiers properties pass�s en 
param�tres (lotsentree et lotspublies).

Pour donner la liste des lots, l'argument de l'option lotsentree doit repr�senter la liste 
des noms (sans extension) des fichiers properties d�crivant ces lots. Cette liste ne doit 
contenir aucun espace et les �l�ments sont s�par�s par des points-virgules.

L'option -repertoire permet d'indiquer le r�pertoire dans lequel se trouvent ces fichiers
properties (r�pertoire courant, sinon).

Le contenu d'un fichier properties d'un lot publi� se pr�sente comme suit (3 propri�t�s, 
toutes obligatoires) : 
lotpublie.thematique = Departement
lotpublie.attributs = nomDEP
lotpublie.date = 01/01/2008

Le contenu d'un fichier properties d'un lot en entr�e se pr�sente comme suit (9 propri�t�s) : 
# arguments obligatoires
lotentree.localisation=PLO
lotentree.chemin=lotfeor.xml
# arguments facultatifs
lotentree.portee=ROUTE
lotentree.recouvrement=O
lotentree.continuite=N
lotentree.concede=N
lotentree.dom=N
lotentree.dispech=N
lotentree.declass=N

Dans ces fichiers properties, les options bool�ennes doivent �tre remplies par "O" ou par "N".

